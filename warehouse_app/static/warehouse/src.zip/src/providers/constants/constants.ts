export const PROXY = 'http://192.168.0.112';

//export const PROXY = '/api';