import { NgModule } from '@angular/core';
import { OdooComponent } from './odoo/odoo';
@NgModule({
	declarations: [OdooComponent],
	imports: [],
	exports: [OdooComponent]
})
export class ComponentsModule {}
