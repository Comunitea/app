import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SlideopPage } from './slideop';

@NgModule({
  declarations: [
    SlideopPage,
  ],
  imports: [
    IonicPageModule.forChild(SlideopPage),
  ],
})
export class SlideopPageModule {}
