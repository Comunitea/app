import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TreepickPage } from './treepick';

@NgModule({
  declarations: [
    TreepickPage,
  ],
  imports: [
    IonicPageModule.forChild(TreepickPage),
  ],
})
export class TreepickPageModule {}
