import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TreeopsPage } from './treeops';


@NgModule({
  declarations: [
    TreeopsPage,
  ],
  imports: [
    IonicPageModule.forChild(TreeopsPage),
  ],
})
export class TreeopsPageModule {}
